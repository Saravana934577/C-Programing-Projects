#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "decode.h"



//function check operation type
OperationType check_operation_type(char *symbol)
{

    //argv[1] is check -e going to encode operation
    if(strcmp(symbol,"-e")==0)
    {
        printf("encoding mode:\n");
        return e_encode;
    }

    //argv[1] is check -d going to decode operation
    if(strcmp(symbol,"-d")==0)
    {
        printf("decoding mode:\n");
        return e_decode;
    }

    //any other comment unsupporded operation
    else
    {
        printf("unsupported mode:\n");
        return e_unsupported;
    }

}


int main(int argc,char *argv[])
{
    //argc in greater than 3 only valid
    if(argc<3)
    {
        printf("Invalid input");
        return 1;
    }


    //it is depends upon the encode operation argv[1]
     if(check_operation_type(argv[1])==e_encode)
     {
        //encodig operation
        EncodeInfo enc_Info;

        //it is checked validadte the encode success
        if(read_and_validate_encode_args(argv,&enc_Info)==e_success)
        {
            printf("Read and validate success\n");

        }

        else
        {
           printf("Read and validate failure\n");
           return 0;    
        }

        //encoding operation going to any success is not come failed encode
        if(do_encoding(&enc_Info)!=e_success)
        {

            printf("encoding failed\n");
            return 0;
        }
        else
        {
           printf("encoding success\n");

        }
        
     }


   // it is depends upon the decode operation argv[1]
    else if(check_operation_type(argv[1])==e_decode)
     {
          //decodig operation
        DecodeInfo dec_Info;

        //it is checked validadte the deccode success call function
        if(read_and_validate_decode_args(argv,&dec_Info)==e_success)
        {
            printf("Read and validate success\n");

        }

        else
        {
           printf("Read and validate failure\n");
           return 0;    
        }

        //decoding operation going to any success is not come failed encode
        if(do_decoding(&dec_Info)!=e_success)
        {

            printf("decoding failed\n");
            return 0;
        }
        else
        {
           printf("decoding success\n");

        }

     }



     else
     {
        //unsupported opearation type
        printf("unsupported operation type\n");
        return 1;
     }

     
    return 0;
}
