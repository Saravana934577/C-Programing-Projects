#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
   if(argv[2]!=NULL)
   {
    if(strstr(argv[2],".bmp")!=NULL)
    {
        encInfo->src_image_fname=argv[2];
    }
    else
    {
        printf("ERROR:source image should be .bmp file\n");
        return e_failure;
    }
   }


   if(argv[3]!=NULL)
   {
    if(strstr(argv[3],".txt")!=NULL)
    {
        encInfo->secret_fname=argv[3];
        strcpy(encInfo->extn_secret_file,"txt");
    }
    else
    {
        printf("ERROR:secret file should be .txt/.c/.h/.sh\n");
        return e_failure;
    }

   }
   if(argv[4]==NULL)
   {
     encInfo->stego_image_fname="default.bmb";
   }
   else
   {
    encInfo->stego_image_fname=argv[4];
   }
   return e_success;

   //check the whether the file name is there or not (before.)
    //check the src file is having(.txt ot .t ot .h or .sh) or not
    //encInfo ->src_image_frame = argv[3];

    //check whether the argv[4] is having NULL or not
    //encInfo -> stego_image_frame = "default . bmp";
    //check the whether the file name is there or not (before.)
    //check the src file is having(.bmp) or not
    //encInfo ->stego_image_frame = argv[4];

    //return failure

}


Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;

}



Status check_capacity(EncodeInfo *encInfo)
{
    //get the image size
  encInfo->image_capacity=get_image_size_for_bmp(encInfo->fptr_src_image);

  //get magic string
  printf("Enter the magic string:");
  scanf("%s",encInfo->Magic_string);
  
  //find the file size
  fseek(encInfo->fptr_secret,0,SEEK_END);
  int size_secret_data=ftell(encInfo->fptr_secret);

  encInfo->size_secret_file = size_secret_data;
rewind(encInfo->fptr_secret);

  //find the inforamtion in magic,extn,secret file
  int size_of_info=4+strlen(encInfo->Magic_string)+4+strlen(encInfo->extn_secret_file)+4+size_secret_data;

  //get 1 char 8 byte of information
   if(encInfo->image_capacity>size_of_info*8)
   {
    printf("sufficiently Capacity");
    return e_success;
   }
   return e_failure;

}



//copy of BMP image header
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char buffer[54];//BMP header is 54 bytes
    rewind(fptr_src_image);//move file pointer to the begining
    fread(buffer,54,1,fptr_src_image);//read the 54 bytes to the souce image
    fwrite(buffer,54,1,fptr_dest_image);//write the 54 bytes in the dest image

    //verify the header id copied successfully
    if(ftell(fptr_src_image)==ftell(fptr_dest_image))
   {
    printf("BMP header copied\n");
    return e_success;
   }
   else
   {
   return e_failure;
   }
    
}

/* Store Magic String size*/
Status encode_magic_string_size(int size1, EncodeInfo *encInfo)
{
    char image_buffer[32];//buffer to hold image bytes

    fread(image_buffer,32,1,encInfo->fptr_src_image);//read the data souce image
    encode_size_to_lsb(size1,image_buffer);//encoder file extention size LSBs image bytes
     fwrite(image_buffer,32,1,encInfo->fptr_stego_image);//write modified bytes to stego image  
     return e_success;
}
//store magic string
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char image_buffer[8];//buffer to hold image bytes
    for(int i=0;i<strlen(magic_string);i++)//loop through each character of magic string
    {
        fread(image_buffer,8,1,encInfo->fptr_src_image);//read the data souce image
        encode_byte_to_lsb(magic_string[i],image_buffer);//Encode character into LSBs image bytes
        fwrite(image_buffer,8,1,encInfo->fptr_stego_image);//write modified bytes to stego image

    }
    return e_success;
}

/*Encode secret file extension size*/
Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
     char image_buffer[32];//buffer to hold image bytes

    fread(image_buffer,32,1,encInfo->fptr_src_image);//read the data souce image
    encode_size_to_lsb(size,image_buffer);//encoder file extention size LSBs image bytes
     fwrite(image_buffer,32,1,encInfo->fptr_stego_image);//write modified bytes to stego image  
     return e_success;

}

/* Encode secret file extenstion */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char image_buffer[8];//buffer to hold image bytes

    for(int i=0;i<strlen(file_extn);i++)
    {
        fread(image_buffer,8,1,encInfo->fptr_src_image);//read the data source image
        encode_byte_to_lsb(file_extn[i],image_buffer);//encoder file extention LSBs image bytes
        fwrite(image_buffer,8,1,encInfo->fptr_stego_image);//write the data bytes in stego image

    }
    return e_success;
}



// Encode Secret File Size  
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char image_buffer[32];//buffer to hold image bytes
    fread(image_buffer,32,1,encInfo->fptr_src_image);//read the data souce image
    encode_size_to_lsb((int)file_size,image_buffer);//encoder file secret data size LSBs image bytes
    fwrite(image_buffer,32,1,encInfo->fptr_stego_image);//write modified bytes to stego image 
    return e_success;
}

/* Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
   rewind(encInfo->fptr_secret);//it is move begining secret file

   //read the secret data in the secert file using 
   fread(encInfo->secret_data,encInfo->size_secret_file,1,encInfo->fptr_secret);

    char image_buffer[8];// Buffer to hold image bytes

   for(int i=0;i<encInfo->size_secret_file;i++)// Loop through each byte of secret data
   {
    fread(image_buffer,8,1,encInfo->fptr_src_image);//read the data souce image
    encode_byte_to_lsb(encInfo->secret_data[i],image_buffer);//encoder file secret data size LSBs image bytes
    fwrite(image_buffer,8,1,encInfo->fptr_stego_image);//write the data bytes in stego image
   }
   return e_success;


}


/* Copy remaining image bytes from src to stego image after encoding */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while((ch = fgetc(fptr_src))!=EOF)//it reamaining character is take it in source file
    {
        fputc(ch,fptr_dest);//it is remaining char write in dest file
    }
    return e_success;
}



/* Encode a byte into LSB of image data array */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for(int i=0;i<8;i++)
    {
   //if it is get the bit in data
         image_buffer[i]=(image_buffer[i]&~1) | ((data>>i) & 1);
       //using 8 bytes to clear the bit store it in lsb only   

    }

}


/*encode the int size take the input at lsb only it*/
Status encode_size_to_lsb(int size, char *imageBuffer)
{
  for(int i=0;i<32;i++)
  {
     //if it is get the bit in size
    imageBuffer[i]=(imageBuffer[i]&~1) |  ((size>>i) & (1));

 //using 32 bytes to clear the bit store it in lsb only   
  }
}


   // Perform the encoding process
Status do_encoding(EncodeInfo *encInfo)
{
    if (open_files(encInfo) != e_success)
        return e_failure;

    if (check_capacity(encInfo) != e_success)
        return e_failure;

    // Copy BMP header (54 bytes)
    if (copy_bmp_header(encInfo->fptr_src_image,
                        encInfo->fptr_stego_image) != e_success)
        return e_failure;

    /* 🔹 1. Encode magic string size */
    if (encode_magic_string_size(strlen(encInfo->Magic_string), encInfo) != e_success)
        return e_failure;

    /* 🔹 2. Encode magic string */
    if (encode_magic_string(encInfo->Magic_string, encInfo)!= e_success)
        return e_failure;

    /* 🔹 3. Encode secret file extension size */
    if (encode_secret_file_extn_size(strlen(encInfo->extn_secret_file),
                                     encInfo) != e_success)
        return e_failure;

    /* 🔹 4. Encode secret file extension */
    if (encode_secret_file_extn(encInfo->extn_secret_file,
                                encInfo) != e_success)
        return e_failure;

    /* 🔹 5. Encode secret file size */
    if (encode_secret_file_size(encInfo->size_secret_file,
                                encInfo) != e_success)
        return e_failure;

    /* 🔹 6. Encode secret file data */
    if (encode_secret_file_data(encInfo) != e_success)
        return e_failure;

    /* 🔹 7. Copy remaining image data */
    if (copy_remaining_img_data(encInfo->fptr_src_image,
                                encInfo->fptr_stego_image) != e_success)
        return e_failure;

    printf("✅ Encoding completed successfully\n");

    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_stego_image);

    return e_success;
}











